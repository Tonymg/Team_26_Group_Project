package TestClasses;

import ProjectClasses.*;


import static org.junit.Assert.*;
import org.junit.Test;
import java.util.ArrayList;


public class RunGameTest
{
	/** checks the testGame choose how many players and gets num of players*/
	@Test
	public void test_choosing_Player_And_GetPlayer() 
	{
		
		
		RunGame testGame = new RunGame();
		
		int numPlayers = testGame.chooseWhichPlayer(1);
		assertEquals("Testing get number of players using chooseWhichPlayer", numPlayers, testGame.getNumPlayers());
		
		numPlayers = testGame.chooseWhichPlayer(2);
		assertEquals("Testing get number of players using chooseWhichPlayer", numPlayers, testGame.getNumPlayers());
		
		
		numPlayers = testGame.chooseWhichPlayer(-9);
		assertEquals("Testing get number of players using chooseWhichPlayer", -1, testGame.getNumPlayers());
		
		numPlayers = testGame.chooseWhichPlayer(3);
		assertEquals("Testing get number of players using chooseWhichPlayer", -1, testGame.getNumPlayers());
		
		numPlayers = testGame.chooseWhichPlayer(9);
		assertEquals("Testing get number of players using chooseWhichPlayer", -1, testGame.getNumPlayers());
		
	}
	
	
	
	/** checks the testGame game finished to see if the game has ended or not*/
	@Test
	public void test_game_finished() 
	{
		
		
		RunGame testGame = new RunGame();
		
		testGame.gameFinished();
		
		assertEquals("Testing gameFinished, default should return false", false, testGame.gameFinished());
		
	}
	
	
	/** checks the testGame oneplayer method and twoplayer method*/
	@Test
	public void test_OnePlayer_And_TwoPlayer() 
	{
		
		
		RunGame testGame = new RunGame();
		
		//testGame.onePlayerGame('g');
		testGame.chooseWhichPlayer(1);	
		
		Pieces testPiece = testGame.getCurPiece();
		
		testGame.onePlayerGame('g');
	
		assertEquals("Testing invalid move hasn't changed position ", testGame.getCurPiece().getCoord(), testPiece.getCoord());
		
		
		testGame.onePlayerGame('s');

		assertEquals("Testing valid move has changed position ", testGame.getCurPiece().getCoord(), testPiece.getCoord());

		
	}
	
	
	
	
	
	
	
}
