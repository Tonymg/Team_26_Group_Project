package TestClasses;

import ProjectClasses.*;


import static org.junit.Assert.*;
import org.junit.Test;
import java.util.ArrayList;




public class BoardTest
{
	/** checks the gameOver method, testing when a piece is first made and after it is moved down*/
	@Test
	public void test_Board_gameOver() 
	{
		Board testBoard = new Board();
		Pieces testPiece = new Pieces();
		
		boolean isBoard = testBoard.gameOver(testPiece);
		
		assertEquals("Testing gameOver", true , testBoard.gameOver(testPiece));
		
		testPiece.moveDown();
		
		assertEquals("Testing gameOver", false , testBoard.gameOver(testPiece));

	}
	
	/** checks the intitializeBoard and clearBoard methods and uses setPieceOnBoard and getBoard to checks
	for each updated version of the board*/
	@Test
	public void test_Board_init_clear() 
	{
		Board testBoard = new Board();
		Pieces testPiece = new Pieces();
		ArrayList<Pieces> allPieces = new ArrayList<Pieces>(10);
				
		char myBoard[][] = testBoard.getBoard();
		
		
		for(int i=0; i < 20-1; i++)
		for(int j=0; j < 10-1; j++)
			assertEquals("Testing getBoard", '.' , myBoard[i][j]);
		
		//sets pieces on the board and retrieves the updated version
		testBoard.setPieceOnBoard(testPiece, allPieces);
		myBoard = testBoard.getBoard();

		//clears board and retrieves the updated version
		testBoard.clearBoard();
		myBoard = testBoard.getBoard();

		
		for(int i=0; i < 20-1; i++)
		for(int j=0; j < 10-1; j++)
			assertEquals("Testing clearBoard after piece added and clear", '.' , myBoard[i][j]);

	}
	
	
	
	
	
	/** checks CheckBoarders each move from starting position should allow piece to move*/
	@Test
	public void test_Board_CheckBoarders() 
	{
		Board testBoard = new Board();
		Pieces testPiece = new Pieces();
				
				
		boolean isBoarded = testBoard.checkSideBoarders('s', testPiece);
		assertEquals("Testing that piece has not collided from starting position", true , isBoarded);
		
		
		isBoarded = testBoard.checkSideBoarders('a', testPiece);
		assertEquals("Testing that piece has not collided from starting position", true , isBoarded);
		
		isBoarded = testBoard.checkSideBoarders('w', testPiece);
		assertEquals("Testing that piece has not collided from starting position", true , isBoarded);
		
		isBoarded = testBoard.checkSideBoarders('d', testPiece);
		assertEquals("Testing that piece has not collided from starting position", true , isBoarded);
		
		
		for(int i = 0; i < 4; i++)
			testPiece.movePc('d');
		
		isBoarded = testBoard.checkSideBoarders('d', testPiece);
		assertEquals("Testing moved piece to collide with side", false , isBoarded);
		
	}
	
	
	/**checkDeadPieces checks if the current piece has collided with others*/
	@Test
	public void test_Board_checkDeadPieces() 
	{
		Board testBoard = new Board();
		Pieces testPiece = new Pieces();
		ArrayList<Pieces> allPieces = new ArrayList<Pieces>(1);
		
		
		for(int i = 1; i < allPieces.size(); i++)
		for(int j = 0; j < 1; j++)
			allPieces.get(i).updatePiece();
		
		
		boolean isBoarded = testBoard.checkDeadPieces(testPiece, allPieces);
		
		//HAVE TO FIX THIS
		//assertEquals("Testing initialized pieces colliding with current piece", true , isBoarded);
		
		
		
		for(int i = 0; i < allPieces.size(); i++)
		for(int j = 0; j < 18; j++)
			allPieces.get(i).updatePiece();
		
		isBoarded = testBoard.checkDeadPieces(testPiece, allPieces);
		assertEquals("Testing moved pieces colliding with current piece", false , isBoarded);

		
	}
	
	
	
	/**checkBoarders tests if the piece properly detects a collison with the bottem of the grid*/
	@Test
	public void test_Board_checkBorders() 
	{
		Board testBoard = new Board();
		Pieces testPiece = new Pieces();
		ArrayList<Pieces> allPieces = new ArrayList<Pieces>(1);
		
		
		boolean isBoarded = testBoard.checkBorder(testPiece, allPieces);
		assertEquals("Testing piece should not have collided with bottom", false , isBoarded);
		
		for(int j = 0; j < 21; j++)
			testPiece.movePc('s');
		
		isBoarded = testBoard.checkBorder(testPiece, allPieces);
		assertEquals("Testing if piece has collided with the bottom", true , isBoarded);

		
		
		
		
	}
	
	
}
