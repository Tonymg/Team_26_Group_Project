package ProjectClasses;


import java.util.ArrayList;
import java.util.*; 


//Assignment requirements: provide trace of this code.
public class HumanPlayer extends Player
{
	
	//private char playerInput;
	//private int score;
	
	public HumanPlayer()
	{
		super();
	}
	/*
	/** takes player input and sets the playerinput var and returns input char
	public char playerMove()
	{
		char holder = this.playerInput;
		this.playerInput = 'y';
		
		return holder;
	}
	*/

	
	/*
	//updates the new points to the players total score
	public void upDateScore(int newPoints)
	{
		
		//super.upDateScore(newPoints);
		
	}
	
	
	//retrieves the players score
	public int getScore()
	{
		
		return super.getScore();
	}
	*/
}
