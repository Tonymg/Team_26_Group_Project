//package TestClasses;

import TestClasses.*;

import org.junit.runner.RunWith;		
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;



@RunWith(Suite.class)				
@SuiteClasses({				
	BoardTest.class,
	CompPlayerTest.class,
	HumanPlayerTest.class,
	PiecesTest.class,
	RunGameTest.class,
})

public class MySuite 
{				
			// This class remains empty, it is used only as a holder for the above annotations		
}

