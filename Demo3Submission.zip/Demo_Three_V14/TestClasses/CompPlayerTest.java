package TestClasses;


import ProjectClasses.*;


import static org.junit.Assert.*;
import org.junit.Test;
import java.util.ArrayList;


public class CompPlayerTest
{
	/** checks the CompPlayer inherited methods setMove and getMove*/
	@Test
	public void test_CompPlayer_settingAMove() 
	{
		CompPlayer testPlayer = new CompPlayer();
		testPlayer.setMove('1');
		assertEquals("Testing setMove", '.', testPlayer.getMove());
		
		testPlayer.setMove('8');
		assertEquals("Testing setMove", '.', testPlayer.getMove());
		
		testPlayer.setMove('a');
		assertEquals("Testing setMove", 'a', testPlayer.getMove());
		
		testPlayer.setMove('S');
		assertEquals("Testing setMove", 's', testPlayer.getMove());
		
		testPlayer.setMove('d');
		assertEquals("Testing setMove", 'd', testPlayer.getMove());
		
		testPlayer.setMove('W');
		assertEquals("Testing setMove", 'w', testPlayer.getMove());
	}
	
	
	/** checks the Compplayer inherited methods setScore and getScore*/
	@Test
	public void test_CompPlayer_settingScoreandGettingScore() 
	{
		CompPlayer testPlayer = new CompPlayer();
		
		testPlayer.upDateScore('a');
		assertEquals("Testing setScore", 97, testPlayer.getScore());
		
		testPlayer.upDateScore(-100);
		assertEquals("Testing setScore", 97, testPlayer.getScore());
		
		testPlayer.upDateScore(100);
		assertEquals("Testing setScore", 197, testPlayer.getScore());
		
		testPlayer.upDateScore(1000000);
		assertEquals("Testing setScore", 1000197, testPlayer.getScore());
		
		
	}
	
	
	
	/** checks the calcMove methods*/
	@Test
	public void test_CompPlayer_calMove() 
	{
		
		CompPlayer testPlayer = new CompPlayer();
		ArrayList<Pieces> allPieces = new ArrayList<Pieces>(10);
		char c = testPlayer.calcMove(allPieces);
		
		assertEquals("Testing calcMove", c, testPlayer.getMove());

	}
	
}
