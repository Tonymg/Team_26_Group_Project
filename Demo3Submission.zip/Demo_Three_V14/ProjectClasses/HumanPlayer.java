package ProjectClasses;


import java.util.ArrayList;
import java.util.*; 


//Assignment requirements: provide trace of this code.
public class HumanPlayer extends Player
{
	
	public HumanPlayer()
	{
		super();
	}
}
