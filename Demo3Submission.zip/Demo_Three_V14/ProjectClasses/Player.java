/**Parent class for the human and comp player classes */

package ProjectClasses;





import java.util.ArrayList;
import java.util.*; 


public abstract class Player
{
	
	protected char playerInput;
	private int score;
	
	public Player()
	{
		
		this.score = 0;
		this.playerInput = '.';
	}
	
	
	/**handles moves by the computer */
	public void setMove(char c)
	{
		//make upper to lower
		if(c == 'A')
		{
			c = 'a';
		}
		else if( c == 'S')
		{
			c = 's';
		}
		else if ( c == 'D' )
		{
			c = 'd';
		}
		else if(c == 'W')
		{
			c = 'w';
		}
		
		
		if (c == 'a' || c == 's' || c == 'd' || c == 'w')
		{
			this.playerInput = c;
		}
		
	}
	
	
	/**returns the computer's move */
	public char getMove()
	{
		return this.playerInput;
		
	}
	
	
	/**updates the players score based on their moves */
	public void upDateScore(int newPoints)
	{
		if(newPoints > 0)
		{
			this.score += newPoints;	
		}
	}
	
	/**returns the player's score */
	public int getScore()
	{
		return this.score;	
	}
	
}
