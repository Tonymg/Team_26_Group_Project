/**This class creates the pieces and decides shapes of the pieces and handles the coordinates of the individual bloocks on the pieces */

package ProjectClasses;




import java.util.Random;
import java.util.List;
import java.util.*; 
import java.util.List; 
import java.util.Arrays;
import java.util.Scanner;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;


public class Pieces
{
	
	boolean isAlive = false;
	
	private final String SHAPES[] = {"NoShape", "ZShape", "SShape", "LineShape", 
		"TShape", "SquareShape", "LShape", "MirroredLShape"};

	private String curShape = " ";
	private final int SHAPESIZE = 8;
	
	private ArrayList<Integer> coords = new ArrayList<Integer>();
	
	private char shapeId = ' ';



	public Pieces()
	{		
		intitializePieces();
	}
	
	/**Copy constructor */
	public Pieces(Pieces pieceToCopy){
		for(int i = 0; i<pieceToCopy.coords.size(); i++){
			int a = pieceToCopy.coords.get(i);
			this.coords.add(a);
			this.shapeId = pieceToCopy.getShapeID();			
		}

	}
	
	/** SETS COORDINATES AND CHOOSE A RANDOM SHAPE*/
	public void intitializePieces()
	{
		/** choose shape determines which shape*/
		chooseShape();
		/** setCoord determines what spaces to fill based off the shape choosen*/
		setCoord();
	}
	

	/** Randomly picks a number and chooses a shape based off of the number*/
	public void chooseShape()
	{
		Random rand = new Random();
        int randInt = Math.abs(rand.nextInt()) % 7 + 1;
        this.curShape = SHAPES[randInt];
		
	}
	
	/**sets whether this piece is currently the one in play or not */
	public void setStatus(boolean notAct)
	{
		this.isAlive = notAct;
	}
	
	/**returns if this piece is the active one or not */
	public boolean getStatus()
	{
		return this.isAlive;
	}
	
	/**returns shape of piece */
	public String getPiece()
	{
		return this.curShape;
	}
	
	/**returns a character that corresponds to the shape of the piece */
	public char getShapeID()
	{
		return this.shapeId;
	}
	
	
	/** SETS THE STARTING COORDINATES OF THE SHAPE DEPENDING ON WHAT IT IS*/
	public void setCoord()
	{
		
		if (this.curShape == "NoShape")
		{
			
		}
		else if (this.curShape == "SShape") 
		{
			this.coords.add(5);
			this.coords.add(0);
			this.coords.add(5);
			this.coords.add(1);
			this.coords.add(6);
			this.coords.add(1);
			this.coords.add(6);
			this.coords.add(2);

			this.shapeId = 'S';
			
		}
		else if (this.curShape == "ZShape") 
		{
			this.coords.add(6);
			this.coords.add(0);
			this.coords.add(6);
			this.coords.add(1);
			this.coords.add(5);
			this.coords.add(1);
			this.coords.add(5);
			this.coords.add(2);

			this.shapeId = 'Z';
		}
		else if (this.curShape == "LineShape") 
		{
			this.coords.add(5);
			this.coords.add(0);
			this.coords.add(5);
			this.coords.add(1);
			this.coords.add(5);
			this.coords.add(2);
			this.coords.add(5);
			this.coords.add(3);

			this.shapeId = '|';
		}
		else if (this.curShape == "TShape") 
		{
			this.coords.add(5);
			this.coords.add(0);
			this.coords.add(5);
			this.coords.add(1);
			this.coords.add(4);
			this.coords.add(1);
			this.coords.add(6);
			this.coords.add(1);

			this.shapeId = 'T';
		}
		else if (this.curShape == "SquareShape") 
		{
			this.coords.add(5);
			this.coords.add(0);
			this.coords.add(5);
			this.coords.add(1);
			this.coords.add(6);
			this.coords.add(0);
			this.coords.add(6);
			this.coords.add(1);

			this.shapeId = 'B';
		}
		else if (this.curShape == "LShape") 
		{
			this.coords.add(5);
			this.coords.add(0);
			this.coords.add(6);
			this.coords.add(0);
			this.coords.add(6);
			this.coords.add(1);
			this.coords.add(6);
			this.coords.add(2);

			this.shapeId = 'L';
		}
		else if (this.curShape == "MirroredLShape") 
		{
			this.coords.add(5);
			this.coords.add(0);
			this.coords.add(4);
			this.coords.add(0);
			this.coords.add(4);
			this.coords.add(1);
			this.coords.add(4);
			this.coords.add(2);

			this.shapeId = 'J';
		}

	
	}
	
	
	/** returns the coordinates of the shape*/
	public ArrayList<Integer> getCoord()
	{
		
		ArrayList<Integer> holder = new ArrayList<Integer>();
		
		if (this.coords != null)
		{
			for (int i = 0; i < this.coords.size(); i++)
			{		
				holder.add(this.coords.get(i));
			}
			
			return holder;

		}
		
		return holder;
		
	}
	
	
	/** MOVES ONE COORDINATE DOWN */
	public void moveOneDown(int yCoord)
	{
		
		int holder = this.coords.get(yCoord);
		this.coords.set(yCoord, holder+1);

	}
	
	/** MOVES THE ENTIRE PIECE DOWN */
	public void updatePiece()
	{
		for (int i = 1; i < this.coords.size(); i+=2)
		{
			Integer holder = this.coords.get(i);
			this.coords.set(i, holder + 1);
		}
	}
	
	/** TAKES A DIRECTION AND CALLS THE RIGHT FUNCTION BASED OF THE CHAR*/
	public void movePc(char m)
	{
		
	
		if (m == 'w')
		{
			moveRotate();
		}
		else if(m == 's')
		{
			moveDown();
		}
		else if(m == 'a')
		{
			moveLeft();
		}
		else if(m == 'd')
		{
			moveRight();
		}
		
		
		
	}
	
	/**this method does the math to rotate the piece and checks if the move is valid before updating the piece to rotate it */
	public Pieces moveRotate()

	{
		Pieces temp = new Pieces(this);
		Integer middleX = this.coords.get(2);
		Integer middleY = this.coords.get(3);

		Integer oldXa = this.coords.get(0);
		Integer oldYa = this.coords.get(1);

		Integer newXa = -(oldYa - middleY ) + middleX;
		Integer newYa = (oldXa - middleX ) + middleY;

		Integer oldXb = this.coords.get(2);
		Integer oldYb = this.coords.get(3);

		Integer newXb = -(oldYb - middleY ) + middleX;
		Integer newYb = (oldXb - middleX ) + middleY;

		Integer oldXc = this.coords.get(4);
		Integer oldYc = this.coords.get(5);

		Integer newXc = -(oldYc - middleY ) + middleX;
		Integer newYc = (oldXc - middleX ) + middleY;

		Integer oldXd = this.coords.get(6);
		Integer oldYd = this.coords.get(7);

		Integer newXd = -(oldYd - middleY ) + middleX;
		Integer newYd = (oldXd - middleX ) + middleY;
		
		if(newYa>=0 && newYa<=19 && newYb>=0 && newYb<=19 && newYc>=0 && newYc<=19 && newYd>=0 && newYd<=19){
			/**Checks if the new y values are valid */
			if (newXa>=0 && newXa<=9 && newXb>=0 && newXb<=9 && newXc>=0 && newXc<=9 && newXd>=0 && newXd<=9){
				/**Checks if the new x values are valid.  This is if everything is okay */
				temp.coords.set(0, newXa);
				temp.coords.set(1, newYa);
				temp.coords.set(2, newXb);
				temp.coords.set(3, newYb);
				temp.coords.set(4, newXc);
				temp.coords.set(5, newYc);
				temp.coords.set(6, newXd);
				temp.coords.set(7, newYd);
				return temp;	
			}
			else if(newXa<0 || newXb<0 || newXc<0 || newXd<0){
				/**Checks if the piece is going to rotate off the left side */
				if(newXa<-1 || newXb<-1 || newXc<-1 || newXd<-1){
					/**Checks how far off the board the piece is */
					newXa+=2;
					newXb+=2;
					newXc+=2;
					newXd+=2;

					temp.coords.set(0, newXa);
					temp.coords.set(1, newYa);
					temp.coords.set(2, newXb);
					temp.coords.set(3, newYb);
					temp.coords.set(4, newXc);
					temp.coords.set(5, newYc);
					temp.coords.set(6, newXd);
					temp.coords.set(7, newYd);
					return temp;	
				}
				else{

					newXa++;
					newXb++;
					newXc++;
					newXd++;
	
					temp.coords.set(0, newXa);
					temp.coords.set(1, newYa);
					temp.coords.set(2, newXb);
					temp.coords.set(3, newYb);
					temp.coords.set(4, newXc);
					temp.coords.set(5, newYc);
					temp.coords.set(6, newXd);
					temp.coords.set(7, newYd);
					return temp;	
				}
			}
			else if(newXa>9 || newXb>9 || newXc>9 || newXd>9){
				/**Checks if the piece is going to rotate off the right side */
				if(newXa>10 || newXb>10 || newXc>10 || newXd>10){
					/**Checks how far off the board the piece is going to rotate and adjusts accordingly */
					newXa-=2;
					newXb-=2;
					newXc-=2;
					newXd-=2;

					temp.coords.set(0, newXa);
					temp.coords.set(1, newYa);
					temp.coords.set(2, newXb);
					temp.coords.set(3, newYb);
					temp.coords.set(4, newXc);
					temp.coords.set(5, newYc);
					temp.coords.set(6, newXd);
					temp.coords.set(7, newYd);
					return temp;
				}
				else{
					newXa--;
					newXb--;
					newXc--;
					newXd--;
	
					temp.coords.set(0, newXa);
					temp.coords.set(1, newYa);
					temp.coords.set(2, newXb);
					temp.coords.set(3, newYb);
					temp.coords.set(4, newXc);
					temp.coords.set(5, newYc);
					temp.coords.set(6, newXd);
					temp.coords.set(7, newYd);
					return temp;
				}
			}
		}
		else if(newXa>=0 && newXa<=9 && newXb>=0 && newXb<=9 && newXc>=0 && newXc<=9 && newXd>=0 && newXd<=9){
			/**Checks that the new x values are in the board */
			if(newYa>=0 && newYa<=19 && newYb>=0 && newYb<=19 && newYc>=0 && newYc<=19 && newYd>=0 && newYd<=19){
				/**Checks that the new y values are in the board.  This is if everything is ok */
				temp.coords.set(0, newXa);
				temp.coords.set(1, newYa);
				temp.coords.set(2, newXb);
				temp.coords.set(3, newYb);
				temp.coords.set(4, newXc);
				temp.coords.set(5, newYc);
				temp.coords.set(6, newXd);
				temp.coords.set(7, newYd);
				return temp;
			}
			else if(newYa<0 || newYb<0 || newYc<0 || newYd<0){
				/**Checks if the piece will rotate off the top of the board */
				if(newYa<-1 || newYb<-1 || newYc<-1 || newYd<-1){
					/**Checks if the how far off the right side the piece will be */
					newYa+=2;
					newYb+=2;
					newYc+=2;
					newYd+=2;

					temp.coords.set(0, newXa);
					temp.coords.set(1, newYa);
					temp.coords.set(2, newXb);
					temp.coords.set(3, newYb);
					temp.coords.set(4, newXc);
					temp.coords.set(5, newYc);
					temp.coords.set(6, newXd);
					temp.coords.set(7, newYd);
					return temp;
				}
				else{
					newYa++;
					newYb++;
					newYc++;
					newYd++;
	
					temp.coords.set(0, newXa);
					temp.coords.set(1, newYa);
					temp.coords.set(2, newXb);
					temp.coords.set(3, newYb);
					temp.coords.set(4, newXc);
					temp.coords.set(5, newYc);
					temp.coords.set(6, newXd);
					temp.coords.set(7, newYd);
					return temp;
				}
			}
		}
		return temp;
		
	}
	
	/**rotates the piece */
	public void rotatePiece(){
		Pieces temp = moveRotate();
		for (int i = 0; i<coords.size(); i++){
			coords.set(i, temp.coords.get(i));
		}
	}
	
	/** MOVES PIECE LEFT*/
	public void moveLeft()
	{
		for (int i = 0; i < this.coords.size()-1; i+=2)
		{
			Integer holder = this.coords.get(i);
			this.coords.set(i, holder - 1);
		}
	}
	
	/** MOVES PIECE RIGHT*/
	public void moveRight()
	{
		for (int i = 0; i < this.coords.size()-1; i+=2)
		{
			Integer holder = this.coords.get(i);
			this.coords.set(i, holder + 1);
		}
	}
	
	/** MOVES PIECE DOWN*/
	public void moveDown()
	{
		for (int i = 1; i <= this.coords.size()-1; i+=2)
		{
			Integer holder = this.coords.get(i);
			this.coords.set(i, holder + 1);
		}
	}
	
	/** REMOVES BLOCK IN PIECE*/
	public void removeBlock(int xCoord, int yCoord)
	{
		this.coords.remove(xCoord);
		this.coords.remove(yCoord);
	}
	
}
