package ProjectClasses;

import java.io.*;
import java.io.File;
import java.util.Scanner;

public class HighScore
{
  private String oldScoreString;
  private int oldScore;
  private int newScore;

    
	/**GETS THE PLAYERS SCORE AND UPDATES THE FILE WITH CURRENT INFORMATION*/
   public void write(int newScore)
   {
        String content  = Integer.toString(newScore);
        try
        {
          Writer w = new FileWriter("highScore.txt");
          w.write(content);
          w.close();
        }
        catch (IOException e)
        {
          e.printStackTrace();
        }
    }

	/**CALCULATES IF THE CURRENT SCORE IS BETTER THAN THE HIGH SCORE AND REPLACES IT*/
    public void run (int aNewScore)
    {
      try
      {
        File file = new File("highScore.txt");
        Scanner sc = new Scanner(file);
        String oldScoreString = sc.nextLine();
        int oldScore = Integer.parseInt(oldScoreString);

        int newScore = aNewScore; //get score from game;
        if(newScore>oldScore)
        {
          write(newScore);
        }
      }
    catch (IOException e)
      {
       e.printStackTrace();
      }
   }

	/**RETRIVES THE STORED HIGH SCORE FROM FILE AND RETURNS IT AS A STRING*/
   public String getScore ()
   {
    try
      {
        File file = new File("highScore.txt");
        Scanner sc = new Scanner(file);
        String oldScoreString2 = sc.nextLine();
        return oldScoreString2;
        }
    catch (IOException e)
      {
       e.printStackTrace();
       return "There was an error";
      }
   }
}
