/**This class handles graphical outputs, key inputs and the timer */

import java.util.ArrayList;
import java.util.*; 
import java.util.List; 
import java.util.Arrays;


import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import java.io.File;


public class Gui extends JFrame implements KeyListener 
{
	
	JLabel label;
	private char playerMove = ' ';
	RunGame guiGame1;
	RunGame guiGame2;
	boolean escButton = false;
	boolean isHomeScreen = true;
	int numPlayers = 0;
	private char whichScreen = 'H';
	//JPanel p = new JPanel();
	JFrame f = new JFrame();
	private boolean inProgress = false;



	public Gui(String s)
	{
		super(s);
		//p = new JPanel();
		f = new JFrame();
		
		try
      {
				/**This section makes the graphics window and sets the background image.  It adds a keylistener to the graphics window as well */
				label = new JLabel(new ImageIcon(ImageIO.read(new File("TetrisBoard.png"))));
				label.addKeyListener(this);
				label.setFocusable(true);
				label.setFocusTraversalKeysEnabled(false);
			
				f.setContentPane(label);
				f.getContentPane().setLayout(new GridLayout(20, 10));
				}
						catch (IOException e)
				{
						e.printStackTrace();
				}
		
		f.pack();
		f.setVisible(true);
		f.setResizable(false);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		
	}
	
	/**Initialize the proper amount of games depending on number of players */
	public void initGames(RunGame game1)
	{
		guiGame1 = game1;
	}
	
	/**Initialize the proper amount of games depending on number of players */
	public void initGames(RunGame game1, RunGame game2)
	{
		guiGame1 = game1;
		guiGame2 = game2;
	}
	
	/**This boolean keeps track of whether we are in the middle of updating the visual board.  If we are, it prevents the program from updating the visual baord again until it has finished its last update */
	public boolean returnBool()
	{
		return this.inProgress;
	}
	
	/**Set the number of players so the tetris class knows how many to initialize */
	public void setNumOfPlayers(int num)
	{
		
		this.numPlayers = num;
	}
	
	
	public int getNumOfPlayers()
	{
	
		/** this resets the var numPlayers so that the player has to input the number*/
		int holder = this.numPlayers;
		this.numPlayers = 0;
		
		return holder;
	}
	
	/** returns a boolean if the player hits the escape key and also resets it each time*/
	public boolean returnToHome()
	{
		/** this resets the var escButton so that the player has to input the number*/
		boolean holder = this.escButton;
		this.escButton = false;
		
		return holder;
	}
		
	/** Clears the screen*/
	public void deleteContentPaneStuff()
	{
		f.getContentPane().removeAll();
		f.repaint();
	}
		
	public void changeScreen(char c)
	{
		this.whichScreen = c;
	}
	
	
      /** This method looks through the ArrayList of all pieces, dead and alive, and gets
      their coordinates.  The parameter variable should be allPieces()  This method also
      draws the pieces on the board*/
      public void drawPieces(ArrayList<Pieces> allPieces)
	  {
		  
			deleteContentPaneStuff();

			int[][] coords = new int[20][10];
		
			this.inProgress = true;

		
        
			for(int k = 0; k<allPieces.size(); k++){
			
			//System.out.println("entered drawPieces");
			
				allPieces.get(k).getCoord();
				for(int l = 0; l<allPieces.get(k).getCoord().size(); l+=2){
					int temp1 = allPieces.get(k).getCoord().get(l);
					int temp2 = allPieces.get(k).getCoord().get(l+1);
					if (allPieces.get(k).getShapeID() == 'S'){
						coords[temp2][temp1] = 1;
					}
					else if (allPieces.get(k).getShapeID() == 'Z'){
						coords[temp2][temp1] = 2;
					}
					else if (allPieces.get(k).getShapeID() == '|'){
						coords[temp2][temp1] = 3;
					}
					else if (allPieces.get(k).getShapeID() == 'T'){
						coords[temp2][temp1] = 4;
					}
					else if (allPieces.get(k).getShapeID() == 'B'){
						coords[temp2][temp1] = 5;
					}
					else if (allPieces.get(k).getShapeID() == 'L'){
						coords[temp2][temp1] = 6;
					}
					else if (allPieces.get(k).getShapeID() == 'J'){
						coords[temp2][temp1] = 7;
					}
				}
			}

        for(int i= 0; i<20; i++){
          for (int j = 0; j<10; j++){
            if (coords[i][j] == 0){
              try
              {
                JLabel temp = new JLabel(new ImageIcon(ImageIO.read(new File("clear.png"))));
                f.getContentPane().add(temp);
              }
              catch (IOException e)
              {
                e.printStackTrace();
              }
            }
            else if (coords[i][j] == 1){
              try
              {
                JLabel temp = new JLabel(new ImageIcon(ImageIO.read(new File("blue.png"))));
                f.getContentPane().add(temp);
              }
              catch (IOException e)
              {
                e.printStackTrace();
              }
            }
            else if (coords[i][j] == 2){
              try
              {
                JLabel temp = new JLabel(new ImageIcon(ImageIO.read(new File("green.png"))));
                f.getContentPane().add(temp);
              }
              catch (IOException e)
              {
                e.printStackTrace();
              }
            }
            else if (coords[i][j] == 3){
              try
              {
                JLabel temp = new JLabel(new ImageIcon(ImageIO.read(new File("purple.png"))));
                f.getContentPane().add(temp);
              }
              catch (IOException e)
              {
                e.printStackTrace();
              }
            }
            else if (coords[i][j] == 4){
              try
              {
                JLabel temp = new JLabel(new ImageIcon(ImageIO.read(new File("grey.png"))));
                f.getContentPane().add(temp);
              }
              catch (IOException e)
              {
                e.printStackTrace();
              }
            }
						else if (coords[i][j] == 5){
							try
							{
								JLabel temp = new JLabel(new ImageIcon(ImageIO.read(new File("pink.png"))));
								f.getContentPane().add(temp);
							}
							catch (IOException e)
							{
								e.printStackTrace();
							}
						}
						else if (coords[i][j] == 6){
							try
							{
								JLabel temp = new JLabel(new ImageIcon(ImageIO.read(new File("peach.png"))));
								f.getContentPane().add(temp);
							}
							catch (IOException e)
							{
								e.printStackTrace();
							}
						}
						else{
							try
							{
								JLabel temp = new JLabel(new ImageIcon(ImageIO.read(new File("orange.png"))));
								f.getContentPane().add(temp);
							}
							catch (IOException e)
							{
								e.printStackTrace();
							}
						}
          }
        }
		f.pack();
		f.setVisible(true);
		f.setResizable(true);
  
  
		this.inProgress = false;
    }

	
	
	
	
	@Override
    public void keyTyped(KeyEvent e) 
	{
		/*

        if (e.getKeyCode() == KeyEvent.VK_RIGHT) 
		{
            System.out.println("Right key typed");
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT) 
		{
            System.out.println("Left key typed");
        }
		*/

    }

		/**Handles key input, decides which keys are allowed during different stages of the game */
    @Override
    public void keyPressed(KeyEvent e) 
	{

		
		/** if the screen is currently at the home screen allow these keys*/
		if (this.whichScreen == '1' || this.whichScreen == '2')
		{
			char move = ' ';
			
			
			System.out.println("Entering if");
			if (!this.inProgress)
			{
				this.inProgress = true;
			
				System.out.println("Entering");
				if (e.getKeyCode() == KeyEvent.VK_RIGHT) 
				{
					//System.out.println("Right key pressed");
					//deleteContentPaneStuff();
					move = 'd';
					guiGame1.onePlayerGame(move);
					drawPieces(guiGame1.getPieces());

				}
				if (e.getKeyCode() == KeyEvent.VK_LEFT) 
				{
					//System.out.println("Left key pressed");
					//deleteContentPaneStuff();
					move = 'a';
					guiGame1.onePlayerGame(move);
					drawPieces(guiGame1.getPieces());


				}
				if (e.getKeyCode() == KeyEvent.VK_DOWN) 
				{
					//System.out.println("Down key pressed");
					//deleteContentPaneStuff();
					move = 's';
					guiGame1.onePlayerGame(move);
					drawPieces(guiGame1.getPieces());

				}
				if (e.getKeyCode() == KeyEvent.VK_UP) 
				{
					//System.out.println("Up key pressed");
					//deleteContentPaneStuff();
					move = 'w';
					guiGame1.onePlayerGame(move);
					drawPieces(guiGame1.getPieces());


				}
				if (e.getKeyCode() == KeyEvent.VK_ESCAPE) 
				{
					System.out.println("Escape key pressed");
					this.escButton = true;
					this.whichScreen = 'H';

				}
			
				this.inProgress = false;
			}
		}
		/** if the screen is currently at the home screen allow these keys*/
		else if (this.whichScreen == 'H')
		{
			System.out.println("Entering else-if");
			if (e.getKeyCode() == KeyEvent.VK_1) 
			{
				setNumOfPlayers(1);
				//this.numPlayers = 1;
				this.whichScreen = '1';

			}
			if (e.getKeyCode() == KeyEvent.VK_2) 
			{
				setNumOfPlayers(2);
				//this.numPlayers = 2;
				this.whichScreen = '2';
			}
			
			if (e.getKeyCode() == KeyEvent.VK_ESCAPE) 
			{
				System.out.println("GAME OVER");
				System.exit(0);
			}
		}
		/** if the screen is currently at the end screen allow these keys*/
		else if (whichScreen == 'E')
		{
			if (e.getKeyCode() == KeyEvent.VK_ENTER) 
			{				
				this.whichScreen = 'H';
			}
		}
		

    }

    @Override
    public void keyReleased(KeyEvent e) 
	{
		/*
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) 
		{
            System.out.println("Right key Released");
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT) 
		{
            System.out.println("Left key Released");
        }
		*/
    }
	
	
}
