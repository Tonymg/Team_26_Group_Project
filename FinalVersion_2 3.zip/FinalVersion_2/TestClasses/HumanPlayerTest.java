package TestClasses;

import ProjectClasses.*;


import static org.junit.Assert.*;
import org.junit.Test;
import java.util.ArrayList;


public class HumanPlayerTest
{
	/** checks the humanplayer inherited methods setMove and getMove*/
	@Test
	public void test_HumanPlayer_settingAMove() 
	{
		HumanPlayer testPlayer = new HumanPlayer();
		testPlayer.setMove('1');
		assertEquals("Testing setMove", '.', testPlayer.getMove());
		
		testPlayer.setMove('8');
		assertEquals("Testing setMove", '.', testPlayer.getMove());
		
		testPlayer.setMove('a');
		assertEquals("Testing setMove", 'a', testPlayer.getMove());
		
		testPlayer.setMove('S');
		assertEquals("Testing setMove", 's', testPlayer.getMove());
		
		testPlayer.setMove('d');
		assertEquals("Testing setMove", 'd', testPlayer.getMove());
		
		testPlayer.setMove('W');
		assertEquals("Testing setMove", 'w', testPlayer.getMove());
	}
	
	
	/** checks the humanplayer inherited methods setScore and getScore*/
	@Test
	public void test_HumanPlayer_settingScoreandGettingScore() 
	{
		HumanPlayer testPlayer = new HumanPlayer();
		testPlayer.upDateScore('a');
		assertEquals("Testing setScore", 97, testPlayer.getScore());
		
		testPlayer.upDateScore(-100);
		assertEquals("Testing setScore", 97, testPlayer.getScore());
		
		testPlayer.upDateScore(100);
		assertEquals("Testing setScore", 197, testPlayer.getScore());
		
		testPlayer.upDateScore(1000000);
		assertEquals("Testing setScore", 1000197, testPlayer.getScore());
		
		
	}
	
}
