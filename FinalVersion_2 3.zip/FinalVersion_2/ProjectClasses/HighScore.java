/** This class keeps track of who has the highscore on your computer by writing to an output file. */

package ProjectClasses;

import java.io.*;
import java.io.File;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.*;

public class HighScore
{
  private String oldScoreString;
  private int oldScore;
  private int newScore;
  private String userName;

    
  /** writes the name of the player to the output file */
   public void write(String newName, int newScore)
   {
        String content  = Integer.toString(newScore);
        try
        {
          Writer w = new FileWriter("highScore.txt");
		  w.write(newName + "\n");
          w.write(content);
          w.close();
        }
        catch (IOException e)
        {
          e.printStackTrace();
        }
    }

    /** Writes the name of the player and their score to the output file */
    public void run (String newName, int aNewScore)
    {
      try
      {
        File file = new File("highScore.txt");
        Scanner sc = new Scanner(file);
		
		userName = sc.nextLine();
        String oldScoreString = sc.nextLine();
        int oldScore = Integer.parseInt(oldScoreString);

        int newScore = aNewScore; //get score from game;
        if(newScore>oldScore)
        {
          write(newName, newScore);
        }
      }
    catch (IOException e)
      {
       e.printStackTrace();
      }
   }

   /** Gets the highest score from the output file */
   public ArrayList<String> getScore ()
   {
	   
	   ArrayList<String> userInfo = new ArrayList<String>(2);
	   
    try
      {
        File file = new File("highScore.txt");
        Scanner sc = new Scanner(file);
		//String userName = sc.nextLine();
        //String oldScoreString2 = sc.nextLine();
		
		userInfo.add(sc.nextLine());
		userInfo.add(sc.nextLine());
		
        return userInfo;
        }
    catch (IOException e)
      {
       e.printStackTrace();
      // return "There was an error";
	    return userInfo;

      }
   }
}
