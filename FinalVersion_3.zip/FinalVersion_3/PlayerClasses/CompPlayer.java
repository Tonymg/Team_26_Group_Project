package PlayerClasses;

import GameTools.*;

import java.util.ArrayList;
import java.util.*; 



/** Assignment requirements: provide trace of this code.*/
public class CompPlayer extends Player
{
	
	//private char playerInput;
	//private int score;
	private char moves[] = {'a', 's', 'd', 'w'};
	
	
	public CompPlayer()
	{
		super();
	}
	
	/**This method calculates the computers best move
	and returns it represented by a char*/
	public char calcMove(ArrayList<Pieces> allPieces)
	{
		
		
		//replace with proper ai using the allPieces
		//arraylist to determine open spaces and possibly bring in more var if needed
		//System.out.println("entered playerMove");
		Random rand = new Random();
        int randInt = Math.abs(rand.nextInt()) % 4;
		
		this.playerInput = moves[randInt];
		
		
		
		
		return this.playerInput;
	}



}
