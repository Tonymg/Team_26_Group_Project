/**This class is the one that is actually run */

//package logic;

import ProjectClasses.*;
//import PlayerClasses.*;
import GameTools.*;
//import graphics.*;

import java.util.ArrayList;
import java.util.*;
import java.util.List;
import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.io.IOException;

import java.io.File;

import java.io.*;
import javafx.scene.*;
import java.io.FileNotFoundException;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
//import javafx.scene.layout.ColumnConstraints;
//import javafx.scene.layout.GridPane;
import javafx.*;
import javafx.scene.layout.*;
import java.util.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.event.EventHandler;
import javafx.application.Platform;
import javafx.animation.AnimationTimer;
import java.util.Timer;
import java.util.TimerTask;
import javafx.scene.control.SplitPane;
//import javafx.scene.layout.*;
//import javafx.scene.layout.HBox;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Orientation;
import javafx.scene.text.Text; 
import javafx.scene.control.Label;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
//import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.control.TextField;
import javafx.scene.text.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;





public class mainGame extends Application
{
	private char playerMove = ' ';
	//private char whichScreen = 'H';
	private String folder = "graphics/";

	private GridPane gridpane = new GridPane();
	private GridPane gridpane2 = new GridPane();
	private GridPane gridpane3 = new GridPane();
	private SplitPane splitPane = new SplitPane();
	private StackPane stackPane = new StackPane();
	private StackPane userPane = new StackPane();


    private final int numCols = 10;
	private final int numRows = 20;
	private Image mainMenu;
	private Image tetris;
	private Image lose;
	private Image tetris2;
	private Image userImage;
	private ImageView background;
	private ImageView background2;
	private ImageView background3;
	private TextField text = new TextField();
	
	private int countDown = 350;


	boolean isOneGame;
	private RunGame myGame1;
	private RunGame myGame2;
	private int highScore;
	private String highScoreName;
	private String newName;
	boolean isTwoPlayer = false;
	
	private Scene HomeScene;
	private Scene EndScene;
	private Scene GameScene;	
	private Scene GameScene2;
	private Scene UserInput;
	private MediaPlayer myMediaPlayer;


	public mainGame()
	{
		

	}

	/** based off how many players have been choosen initialize the proper amount
	and add the the Gui instance*/
	public void init(int isOne)
	{

		if(isOne == 1)
		{
			/** creates a new game and places it in the GUI to access the keylistener and
			use the info from the game*/
			this.myGame1 = new RunGame();
			
			//updates the users initials for the highscore
			int maxLength = 3;
			if (text.getText().length() > maxLength) 
			{
                String s = text.getText().substring(0, maxLength);
                text.setText(s);
				this.newName = text.getText();
			}
			else
			{
				this.newName = text.getText();
			}

										//which when pressed will run the onePlayerGame in the RunGame object
		}
		else
		{

			/** creates a new game and places it in the GUI to access the keylistener and
			use the info from the game*/
			this.myGame1 = new RunGame();
			this.myGame2 = new RunGame();

		}


	}

	/** Runs the game, includes a timer which acts like the game loop and the keyhandlers which switch screens depending 
	on the game state*/
	public void start (Stage stage) throws FileNotFoundException
	{
		//Background music for game
		//URL resource = getClass().getResource(folder + "sample.mp3");
		myMediaPlayer = new MediaPlayer( new Media(getClass().getResource(folder + "Music.mp3").toString()));
		myMediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
		myMediaPlayer.play();
		
		
		//creates all windows in the game
		initScenes();
			
			
		stage.setTitle("Stacc Attacc");
		stage.setResizable(false);
        stage.setScene(this.HomeScene);
		stage.show();
		
		/** Game timer which goes through the updating and end game scenario. Updates pieces checks if games over 
		and switches game if it is over*/
		Timer timer = new Timer();
			 timer.schedule(new TimerTask() 
			{
				
				@Override
				public void run() 
				{
									
					Platform.runLater(new Runnable() 
					{
						@Override
						public void run() 
						{
			
							
							if(myGame1 != null)
							{
								//if the game is two player time both events
								if(isTwoPlayer)
								{
										if(myGame1.gameFinished() || myGame2.gameFinished())
										{
											updateHighScoreOnGui(2);
											resetGame();
											stage.setScene(EndScene);
										}	
										else
										{
											myGame1.moveAlivePiece();
											drawPieces(myGame1.getPieces(), gridpane2);
											myGame2.moveAlivePiece();
											drawPieces(myGame2.getPieces(), gridpane3);
										}
										
								}
								//if the game is one player time only first player events
								else
								{
									if(myGame1.getNumPlayers() > 0)
									{
										//System.out.println("print me");
										
										if(myGame1.gameFinished())
										{
											getHighScore();
											updateHighScoreOnGui(1);

											resetGame();
											stage.setScene(EndScene);
										}	
										else
										{
											myGame1.moveAlivePiece();
											drawPieces(myGame1.getPieces(), gridpane);
										}
										
									}
								}
							}
							
						}
						});
					}
				}, 0, this.countDown);
	
		
		
		/**key events for each of the screens */
        this.HomeScene.setOnKeyPressed(new EventHandler<KeyEvent>()
		{
           @Override
            public void handle(KeyEvent event)
			{
		
					if(event.getCode() == KeyCode.DIGIT1)
					{
						//System.out.println("entered 1");
						userInputScreen();

						stage.setScene(UserInput);
						
					}
					if (event.getCode() == KeyCode.DIGIT2)
					{
						//System.out.println("entered 1");
						changeScreen('2');
						init(2);
						myGame1.chooseWhichPlayer(1);
						drawPieces(myGame1.getPieces(), gridpane2);
						myGame2.chooseWhichPlayer(1);
						drawPieces(myGame2.getPieces(), gridpane3);
						stage.show();
						
						stage.setScene(GameScene2);

					}
					if (event.getCode() == KeyCode.ESCAPE)
					{
						System.out.println("GAME OVER");
						System.exit(0);
					}
				
            }
        });
		
		/**key events for each of the screens */
        this.UserInput.setOnKeyPressed(new EventHandler<KeyEvent>()
		{
           @Override
            public void handle(KeyEvent event)
			{
		
					if (event.getCode() == KeyCode.ESCAPE)
					{
						stage.setScene(HomeScene);
					}
					
					if (event.getCode() == KeyCode.ENTER) 
					{
						//System.out.println("Enter key pressed");						
						changeScreen('1');
						init(1);
						myGame1.chooseWhichPlayer(1);
						drawPieces(myGame1.getPieces(), gridpane);
						
						//stage.show();
						stage.setScene(GameScene);
					}
					
				
            }
        });
       
	   
	   
	   this.GameScene.setOnKeyPressed(new EventHandler<KeyEvent>()
	   {
           @Override
            public void handle(KeyEvent event)
			{
				
					if (event.getCode() == KeyCode.RIGHT) 
					{
						//System.out.println("Right key pressed");
						myGame1.onePlayerGame('d');
						drawPieces(myGame1.getPieces(), gridpane);
						stage.show();
	
					}
					if (event.getCode() == KeyCode.LEFT) 
					{
						//System.out.println("Left key pressed");
						myGame1.onePlayerGame('a');
						drawPieces(myGame1.getPieces(), gridpane);
						stage.show();
	
	
					}
					if (event.getCode() == KeyCode.DOWN) 
					{
						//System.out.println("Down key pressed");	
						myGame1.onePlayerGame('s');
						drawPieces(myGame1.getPieces(), gridpane);
						stage.show();
	
					}
					if (event.getCode() == KeyCode.UP) 
					{
						//System.out.println("Up key pressed");
						myGame1.onePlayerGame('w');
						drawPieces(myGame1.getPieces(), gridpane);
						stage.show();
					}
					if (event.getCode() == KeyCode.ESCAPE)
					{
						resetGame();
						stage.setScene(HomeScene);

					}
				  
			}
		

		});
		
		 this.GameScene2.setOnKeyPressed(new EventHandler<KeyEvent>(){
           @Override
            public void handle(KeyEvent event)
			{

				//second player
				if (event.getCode() == KeyCode.D) 
					{
						//System.out.println("Right key pressed");
						myGame2.onePlayerGame('d');
						drawPieces(myGame2.getPieces(), gridpane3);
						stage.show();
	
					}
					if (event.getCode() == KeyCode.A) 
					{
						//System.out.println("Left key pressed");
						myGame2.onePlayerGame('a');
						drawPieces(myGame2.getPieces(), gridpane3);
						stage.show();
	
	
					}
					if (event.getCode() == KeyCode.S) 
					{
						//System.out.println("Down key pressed");	
						myGame2.onePlayerGame('s');
						drawPieces(myGame2.getPieces(), gridpane3);
						stage.show();
	
					}
					if (event.getCode() == KeyCode.W) 
					{
						//System.out.println("Up key pressed");
						myGame2.onePlayerGame('w');
						drawPieces(myGame2.getPieces(), gridpane3);
						stage.show();
					}
					if (event.getCode() == KeyCode.ESCAPE)
					{
						resetGame();
						stage.setScene(HomeScene);

					}
					//first player
					if (event.getCode() == KeyCode.RIGHT) 
					{
						//System.out.println("Right key pressed");
						myGame1.onePlayerGame('d');
						drawPieces(myGame1.getPieces(), gridpane2);
						stage.show();
	
					}
					if (event.getCode() == KeyCode.LEFT) 
					{
						//System.out.println("Left key pressed");
						myGame1.onePlayerGame('a');
						drawPieces(myGame1.getPieces(), gridpane2);
						stage.show();
	
	
					}
					if (event.getCode() == KeyCode.DOWN) 
					{
						//System.out.println("Down key pressed");	
						myGame1.onePlayerGame('s');
						drawPieces(myGame1.getPieces(), gridpane2);
						stage.show();
	
					}
					if (event.getCode() == KeyCode.UP) 
					{
						//System.out.println("Up key pressed");
						myGame1.onePlayerGame('w');
						drawPieces(myGame1.getPieces(), gridpane2);
						stage.show();
					}
					if (event.getCode() == KeyCode.ESCAPE)
					{
						resetGame();
						stage.setScene(HomeScene);

					}
				  
			}
		

		});
		
		this.EndScene.setOnKeyPressed(new EventHandler<KeyEvent>(){
           @Override
            public void handle(KeyEvent event){
				
					if (event.getCode() == KeyCode.ENTER) 
					{
						//System.out.println("Enter key pressed");
						stage.setScene(HomeScene);
					}
					
				  
			}
		

		});
		
	}

	/** retrieve the current highscore from a file and determine if the new highscore is more than it*/
	public void getHighScore()
	{
		
		HighScore newScore = new HighScore();
		int score = myGame1.getHumanPlayer().getScore();		
		ArrayList<String> oldInfo = newScore.getScore();
		
		String oldName = oldInfo.get(0);
		
		System.out.println(oldName);
		
		int oldScore = Integer.parseInt(oldInfo.get(1));
		
		newScore.run(newName, score);
		
		
		
		if (score > oldScore)
		{
			System.out.println("You got the new high score! " + this.newName + " New High Score: " + score);
			highScore = score;
			highScoreName = this.newName;
		}
		else if (score == oldScore)
		{
			System.out.println("You matched the high score of " + oldScore + ". You must beat it to get the new high score" );	
			highScore = oldScore;
			highScoreName = oldName;

		}
		else
		{
			System.out.println("You got " + score + ". Get good to beat the high score of " + oldScore);
			highScore = oldScore;
			highScoreName = oldName;

		}
		
		
	}
	
	
	/**creates screen for the user to input their data*/
	public void userInputScreen()
	{
		
		
		userPane.getChildren().clear();


		background = new ImageView(userImage);
        //Shape a = shape;
		background.setX(0);
		background.setY(0);

		background.setFitHeight(596.25);
		background.setFitWidth(297);
		
		background.setPreserveRatio(true);
		
		Label label = new Label();
				
				
		label = new Label("Input Initials");
		label.setVisible(true);
		label.setFont(new Font("Arial", 30));
			
			
		text = new TextField("Enter name");
		text.setFont(new Font("Arial", 25));
		text.setMinWidth(200);
		text.setMaxWidth(250);


		VBox vbox = new VBox();
		vbox.getChildren().addAll(label, text); // button will be left of text
		vbox.setAlignment( Pos.CENTER );

		userPane.getChildren().add(background);
		userPane.getChildren().add(vbox);
		
		
	}
	
	
	
	
	/** takes the highscore and updates the gui based on the information*/
	public void updateHighScoreOnGui(int numOfPlayers)
	{
		
		stackPane.getChildren().clear();


		
		
		background = new ImageView(lose);
        //Shape a = shape;
		background.setX(0);
		background.setY(0);

		background.setFitHeight(596.25);
		background.setFitWidth(297);
		
		background.setPreserveRatio(true);
		
		Label label = new Label();
				
				
		if (numOfPlayers <= 1)
		{
			label = new Label("Top Scorer:\n"+ highScoreName + ": " + highScore);
			label.setVisible(true);
			label.setFont(new Font("Arial", 30));
			
		}
		else
		{
			
			int player1 = myGame1.getHumanPlayer().getScore();
			int player2 = myGame2.getHumanPlayer().getScore();
			
			if(player1 > player2)
			{
				label = new Label("PLAYER ONE WINS");
			}
			else if(player1 == player2)
			{
				label = new Label("TIE GAME");
			}
			else
			{
				label = new Label("PLAYER TWO WINS");
			}
			
			label.setVisible(true);
			label.setFont(new Font("Arial", 20));
		
		}

		VBox vbox = new VBox();
		vbox.getChildren().addAll(label); // button will be left of text
		vbox.setAlignment( Pos.CENTER );

		stackPane.getChildren().add(background);
		stackPane.getChildren().add(vbox);
		
	}

	public void resetGame()
	{
		myGame1 = null;
		myGame2 = null;
	}

	/** changes the type of screen*/
	public void changeScreen(char c)
	{
		
		if(c == '2')
		{
			isTwoPlayer = true;
		}
		else
		{
			isTwoPlayer = false;
		}
		
		gridpane.getChildren().clear();
		gridpane2.getChildren().clear();

	}

	/**brings on all images for each screen and creates each scene*/
	public void initScenes()
	{
	
			try
			{
				this.tetris = new Image(new FileInputStream(folder + "TetrisBoard.png"));
				this.mainMenu = new Image(new FileInputStream(folder + "MainMenu.png"));
				this.lose = new Image(new FileInputStream(folder + "youLose.png")) ;
				//this.tetris2 = new Image(new FileInputStream(folder + "TwoPlayer.png")) ;
				this.userImage = new Image(new FileInputStream(folder + "TwoPlayer.png")) ;


			}
			catch(FileNotFoundException fnfe)
			{
				
			}
			
//MAIN MENU 
		
		background = new ImageView(mainMenu);
        //Shape a = shape;
		background.setX(0);
		background.setY(0);

		background.setFitHeight(596.25);
		background.setFitWidth(297);
		
		background.setPreserveRatio(true);
		
        Group root = new Group(background);
        
        this.HomeScene = new Scene(root, 297, 596.25);
		
		
		
/////////////////////////////////////////////////////////////////////
		
		//UserInput SCREEN
		
		root = new Group();
		root.getChildren().add(userPane);
	
        this.UserInput = new Scene(root, 297, 596.25);
		
/////////////////////////////////////////////////////////////////////
		
		
//SINGLE PLAYER GAME 
		
		
		background = new ImageView();
		background.setX(0);
		background.setY(0);

		background.setFitHeight(596.25);
		background.setFitWidth(297);
		
		background.setPreserveRatio(true);

        gridpane.setMinSize(297, 596.25);
		gridpane.setGridLinesVisible(true);
		
        root = new Group(background);
        root.getChildren().add(gridpane);
        
        for (int i = 0; i<numCols; i++){
            ColumnConstraints colConst = new ColumnConstraints();
            colConst.setPercentWidth(100.0/numCols);
            gridpane.getColumnConstraints().add(colConst);
        }
        for (int i = 0; i<numRows; i++){
            RowConstraints rowConst = new RowConstraints();
            rowConst.setPercentHeight(100.0/numRows);
            gridpane.getRowConstraints().add(rowConst);
        }
        
        this.GameScene = new Scene(root, 297, 596);
		
////////////////////////////////////////////////////////////////////
		
		//TWO PLAYER GAME SETUP
		
		
		background2 = new ImageView(tetris);
		background2.setX(0);
		background2.setY(0);

		background2.setFitHeight(596.25);
		background2.setFitWidth(297);
		
		background2.setPreserveRatio(true);

        gridpane2.setMinSize(297, 596.25);
		
        
        for (int i = 0; i<numCols; i++){
            ColumnConstraints colConst = new ColumnConstraints();
            colConst.setPercentWidth(100.0/numCols);
            gridpane2.getColumnConstraints().add(colConst);
        }
        for (int i = 0; i<numRows; i++){
            RowConstraints rowConst = new RowConstraints();
            rowConst.setPercentHeight(100.0/numRows);
            gridpane2.getRowConstraints().add(rowConst);
        }
		
		
		background3 = new ImageView(tetris);
		background3.setX(0);
		background3.setY(0);

		background3.setFitHeight(596.25);
		background3.setFitWidth(297);
		
		background3.setPreserveRatio(true);

        //gridpane3.setMinSize(396, 795);
		gridpane3.setMinSize(297, 596.25);
						
		//add both panes into  a split pane for two player 
		splitPane.setOrientation(Orientation.HORIZONTAL);
        splitPane.getItems().add(gridpane2);
        splitPane.getItems().add(gridpane3);
		
        root = new Group(background2);
		root.getChildren().add(splitPane);



        
        for (int i = 0; i<numCols; i++){
            ColumnConstraints colConst = new ColumnConstraints();
            colConst.setPercentWidth(100.0/numCols);
            gridpane3.getColumnConstraints().add(colConst);
        }
        for (int i = 0; i<numRows; i++){
            RowConstraints rowConst = new RowConstraints();
            rowConst.setPercentHeight(100.0/numRows);
            gridpane3.getRowConstraints().add(rowConst);
        }
	
        
		
		
        this.GameScene2 = new Scene(root, 305*2, 596.25, Color.RED);

		
		
/////////////////////////////////////////////////////////////////////
		
		//LOSE SCREEN
		
		root = new Group();
		root.getChildren().add(stackPane);
	
        this.EndScene = new Scene(root, 297, 596.25);
		
				
	}

      /** This method looks through the ArrayList of all pieces, dead and alive, and gets
      their coordinates.  The parameter variable should be allPieces()  This method also
      draws the pieces on the board*/
      public void drawPieces(ArrayList<Pieces> allPieces, GridPane pane)
	  {
		  
		pane.getChildren().clear();

        /**Goes through each piece of the allPieces array  */
        for(int i = 0; i<allPieces.size(); i++){
            allPieces.get(i).getCoord();
            /**Go through the coordinates of each piece individually */
            for(int l = 0; l<allPieces.get(i).getCoord().size(); l+=2){
                int x = allPieces.get(i).getCoord().get(l);
                int y = allPieces.get(i).getCoord().get(l+1);

                if (allPieces.get(i).getShapeID() == 'S'){
                    try{
						FileInputStream file = new FileInputStream(folder + "blue.png");
                        Image blueBlock = new Image(file);
						pane.add(new ImageView(blueBlock), x, y);
						file.close();
                    }
                    catch(IOException e){
                        e.printStackTrace();
                    }
                }
                else if (allPieces.get(i).getShapeID() == 'Z'){
                    try{
						FileInputStream file = new FileInputStream(folder + "green.png");
                        Image greenBlock = new Image(file);
						pane.add(new ImageView(greenBlock), x, y);
						file.close();
                    }
                    catch(IOException e){
                        e.printStackTrace();
                    }
                }
                else if (allPieces.get(i).getShapeID() == '|'){
                    try{
						FileInputStream file = new FileInputStream(folder + "purple.png");
                        Image purpleBlock = new Image(file);
						pane.add(new ImageView(purpleBlock), x, y);
						file.close();
                    }
                    catch(IOException e){
                        e.printStackTrace();
                    }
                }
                else if (allPieces.get(i).getShapeID() == 'T'){
                    try{
						FileInputStream file = new FileInputStream(folder + "grey.png");
                        Image greyBlock = new Image(file);
						pane.add(new ImageView(greyBlock), x, y);
						file.close();
                    }
                    catch(IOException e){
                        e.printStackTrace();
                    }
                }
                else if (allPieces.get(i).getShapeID() == 'B'){
                    try{
						FileInputStream file = new FileInputStream(folder + "pink.png");
                        Image pinkBlock = new Image(file);
						pane.add(new ImageView(pinkBlock), x, y);
						file.close();
                    }
                    catch(IOException e){
                        e.printStackTrace();
                    }
                }
                else if (allPieces.get(i).getShapeID() == 'L'){
                    try{
						FileInputStream file = new FileInputStream(folder + "peach.png");
                        Image peachBlock = new Image(new FileInputStream(folder + "peach.png"));
						pane.add(new ImageView(peachBlock), x, y);
						file.close();
                    }
                    catch(IOException e){
                        e.printStackTrace();
                    }
                }
                else if (allPieces.get(i).getShapeID() == 'J'){
                    try{
						FileInputStream file = new FileInputStream(folder + "orange.png");
                        Image orangeBlock = new Image(new FileInputStream(folder + "orange.png"));
						pane.add(new ImageView(orangeBlock), x, y);
						file.close();
                    }
                    catch(IOException e){
                        e.printStackTrace();
                    }
                }
            }
        }
				
		
	}
	public static void main(String[] args)
	{
		
		launch(args);
		
		System.out.println("GAME OVER");


		/** End game */
		System.exit(0);
	}
}
