/**This class is the controller class that everything is implemented from */

package ProjectClasses;


import GameTools.*;
import PlayerClasses.*;

import java.util.*; 
import java.util.List; 
import java.util.Arrays;
import java.util.ArrayList;


public class RunGame 
{

	private Board myBoard;
	private ArrayList<Pieces> allPieces = new ArrayList<Pieces>();
	private Pieces curPiece;
	private boolean isGameOver = false;
	//Player player;
	//private Visuals myVisuals;
	private Player hPlayer = new HumanPlayer();
	private CompPlayer cPlayer = new CompPlayer();
	private int numbOfPlayers = 0;

	
	public RunGame()
	{

		myBoard = new Board();
		intitializePiece();
		//myBoard.printScreen();
		//chooseAmountOfPlayers();

	}
	
	/** CREATES A NEW USER PIECE AND SET IT ON THE BOARD*/
	public void intitializePiece()
	{
		if(this.allPieces.size() <= 0)
		{
			this.curPiece = new Pieces();
			this.allPieces.add(this.curPiece);
			this.curPiece.setStatus(true);
		}
		else if (!this.curPiece.getStatus())
		{
			this.curPiece = new Pieces();
			this.allPieces.add(this.curPiece);
			this.curPiece.setStatus(true);
		}
		
		
		myBoard.setPieceOnBoard(curPiece, allPieces);
		
	}
	
	/** DETERMINES IF THE PLAYER IS PLAYING ALONE OR AGAINST THE COMP*/
	public int chooseWhichPlayer(int num)
	{
		
		/** Deterimines if the player wants to play by themselves or against an ai (haven't implemented yet)*/
		if (num == 1)
		{
			this.numbOfPlayers = 1;
			this.hPlayer = new HumanPlayer();
		}
		else if(num == 2)
		{
			this.numbOfPlayers = 2;
			this.cPlayer = new CompPlayer();

		}	
		else
		{
			this.numbOfPlayers = -1;
			num = -1;
		}

		return num;
				
	}
	
	
	public boolean GameOver()
	{
		return this.isGameOver;
	}
	
	
	
	
	/**returns an array of all the pieces that are on the board, dead or alive */
	public ArrayList<Pieces> getPieces()
	{
		ArrayList<Pieces> holder = new ArrayList<Pieces>();
		
		for (int i = 0; i < this.allPieces.size(); i++)
		{
			Pieces holderPiece = new Pieces();
			holderPiece = this.allPieces.get(i);
			holder.add(holderPiece);
		}
		
		return holder;
		
	}
	
	/** returns the number of players choosen by user*/
	public int getNumPlayers()
	{
		return this.numbOfPlayers;
	}
	
	/** DETERMINES IF THE GAME HAS ENDED OR NOT*/
	public boolean gameFinished()
	{
		
		boolean isOver = false;
		
		/** check for collision*/
		//if (myBoard.checkCollision(this.curPiece, this.allPieces))
		//{
			//System.out.println("new piece collided");
			/** checks if the alive piece is at the top of the screen*/
			isOver = myBoard.gameOver(this.allPieces);
			if(isOver)
			{
				this.isGameOver = true;
			}
		//}
		
		return this.isGameOver;
	}
	
	
	/** Returns the human player that is currently being used*/
	public Player getHumanPlayer()
	{
		
		Player holder = new HumanPlayer();

		if(this.hPlayer != null)
		{
			holder = this.hPlayer;
		}
		
		return holder;
		
	}
	
	
	/** returns a copy of the current piece*/
	public Pieces getCurPiece()
	{
		Pieces holder = new Pieces();
		
		//copy coordinates over
		for(int i = 0; i < this.curPiece.getCoord().size(); i++)
		{
			Integer inHold = this.curPiece.getCoord().get(i);
			holder.getCoord().set(i, inHold);
		}
		
		return holder;
	}
		
	
	
	/** Returns the computer player that is currently being used*/
	public CompPlayer getCompPlayer()
	{
		
		CompPlayer holder = new CompPlayer();

		if(this.cPlayer != null)
		{
			holder = this.cPlayer;
		}
		
		return holder;
		
	}
	
	/** RUNS ONLY IF PLAYER IS PLAYING ALONE*/
	public void onePlayerGame(char move)
	{
		
		//make sure hPlayer has been initialized to avoid a runtime error
		if(hPlayer != null)
		{
			
			
			hPlayer.setMove(move);
			myBoard.clearBoard();

			/** check if rotation is possible */
			if (hPlayer.getMove() == 'w' && !(myBoard.checkRotation(curPiece.moveRotate(), allPieces))){
				curPiece.rotatePiece();
			}
		
			
			//checks if game has been finished
			gameFinished();
			
			myBoard.updatePieces(move, this.curPiece);				
			myBoard.setPieceOnBoard(this.curPiece, this.allPieces);
			/** resets the blocks to be able to collide again*/
			myBoard.resetSideColWithBlcs();
			
			
			
			/** check for collision*/
			if (myBoard.checkCollision(curPiece, allPieces))
			{
				
				/** Takes the num of deleted lines and updates the player score using it and 
				//resets the deleted lines number*/
				System.out.print("entered if");
				this.hPlayer.upDateScore(this.myBoard.getdeletedLinesNum() * 100);
				this.myBoard.resetDeletedLinesNum();
			
				
				/** if piece has collided deactivate current piece and create new one*/
				this.curPiece.setStatus(false);
				this.intitializePiece();

			}
			else
			{
				//myBoard.updatePieces(move, this.curPiece);				
				//myBoard.setPieceOnBoard(this.curPiece, this.allPieces);
			
			}
			
			
			//checks if game has been finished
		
		
		
			myBoard.printScreen();
			
			System.out.println("Player Score: " + this.hPlayer.getScore());
		}
		
	}
	
	
	/**CURRETLY ONLY RUNS THE AI OF THE GAME WITH THE COMPPLAYER TO ACCESS THE CALCMOVE METHOD */
	public void twoPlayerGame(char move)
	{
		//make sure cPlayer has been initialized to avoid a runtime error
		if(cPlayer != null)
		{
			//cPlayer.setMove(move);
			myBoard.clearBoard();

			/** check if rotation is possible */
			if (cPlayer.getMove() == 'w' && !(myBoard.checkRotation(curPiece.moveRotate(), allPieces))){
				curPiece.rotatePiece();
			}
		
			myBoard.updatePieces(move, this.curPiece);
			myBoard.setPieceOnBoard(this.curPiece, this.allPieces);
			
			
			/** resets the blocks to be able to collide again*/
			myBoard.resetSideColWithBlcs();
			
			
			/** check for collision*/
			if (myBoard.checkCollision(curPiece, allPieces))
			{
				
				/** Takes the num of deleted lines and updates the player score using it and 
				//resets the deleted lines number*/
				this.cPlayer.upDateScore(this.myBoard.getdeletedLinesNum()*100);
				this.myBoard.resetDeletedLinesNum();
			
				
				/** if piece has collided deactivate current piece and create new one*/
				this.curPiece.setStatus(false);
				this.intitializePiece();				
			}
		
		
		
			myBoard.printScreen();
			
			
			System.out.println("Comp Score: " + this.cPlayer.getScore());
			
		}
	}
	
	
	
	/** moves alive piece down one if the user prompts it to do so*/
	public void moveAlivePiece()
	{
		//determines if the game is one player or two
		char move = 's';
		
		
		
		if (this.numbOfPlayers == 1)
		{	
			onePlayerGame(move);
		}
		else
		{
			twoPlayerGame(move);
		}
	
	}
	
}
	