package TestClasses;

import ProjectClasses.*;


import static org.junit.Assert.*;
import org.junit.Test;
import java.util.ArrayList;


public class PiecesTest
{
	/** checks the Pieces set and get status methods*/
	@Test
	public void test_Pieces_setStatus() 
	{
		Pieces testPiece = new Pieces();
		testPiece.setStatus(false);
		
		assertEquals("Testing getStatus", false, testPiece.getStatus());
		
	}
	
	
	
	/** checks the Pieces movements left right down and rotates properly*/
	@Test
	public void test_Pieces_movements() 
	{
		Pieces testPiece = new Pieces();
		ArrayList<Integer> coords = testPiece.getCoord();
		
		assertEquals("Testing getCoord before move", coords, testPiece.getCoord());
		
		//move left
		testPiece.movePc('a');
		coords = testPiece.getCoord();
		assertEquals("Testing getCoord after left move", coords, testPiece.getCoord());
		
		//move down
		testPiece.movePc('s');
		coords = testPiece.getCoord();
		assertEquals("Testing getCoord after down move", coords, testPiece.getCoord());
		
		//move right
		testPiece.movePc('d');
		coords = testPiece.getCoord();
		assertEquals("Testing getCoord after right move", coords, testPiece.getCoord());
		
		//rotate
		Pieces holdPiece = testPiece.moveRotate();
		coords = holdPiece.getCoord();
		assertEquals("Testing getCoord after rotate move", coords, holdPiece.getCoord());
		
		
		//move down using updatePiece
		testPiece.updatePiece();
		coords = testPiece.getCoord();
		assertEquals("Testing getCoord after down move using updatePiece", coords, testPiece.getCoord());
		
		
		
		//testing removing a block
		testPiece.removeBlock(testPiece.getCoord().get(0), testPiece.getCoord().get(1));
		assertEquals("Testing removing a block", 6, testPiece.getCoord().size());

		
	}

	
	
}
